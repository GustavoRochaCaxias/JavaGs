package br.com.fiap.beans;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Embarcacoes {
	private int idembarcacoes;
	private String nomebarcacoes;
	private String tipo;
	private String bandeira;
	private double peso;
	
	public Embarcacoes() {
		super();
	}

	public Embarcacoes(int idembarcacoes, String nomebarcacoes, String tipo,String bandeira, double peso) {
		super();
		this.idembarcacoes = idembarcacoes;
		this.nomebarcacoes = nomebarcacoes;
		this.tipo = tipo;
		this.bandeira = bandeira;
		this.peso = peso;
	}

	public int getIdembarcacoes() {
		return idembarcacoes;
	}

	public void setIdembarcacoes(int idembarcacoes) {
		this.idembarcacoes = idembarcacoes;
	}

	public String getNomebarcacoes() {
		return nomebarcacoes;
	}

	public void setNomebarcacoes(String nomebarcacoes) {
		this.nomebarcacoes = nomebarcacoes;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getBandeira() {
		return bandeira;
	}

	public void setBandeira(String bandeira) {
		this.bandeira = bandeira;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}
	
}
