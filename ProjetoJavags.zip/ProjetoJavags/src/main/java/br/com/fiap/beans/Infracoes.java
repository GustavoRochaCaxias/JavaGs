package br.com.fiap.beans;

import java.time.LocalDateTime;

public class Infracoes {

	    private int idInfracao;
	    private int idEmbarcacoes;
	    private LocalDateTime dataHora;
	    private String tipoInfracao;
	    private String descricao;
	    private String penalidade;

	    // Getters and Setters

	    public int getIdInfracao() {
	        return idInfracao;
	    }

	    public void setIdInfracao(int idInfracao) {
	        this.idInfracao = idInfracao;
	    }

	    public int getIdEmbarcacoes() {
	        return idEmbarcacoes;
	    }

	    public void setIdEmbarcacoes(int idEmbarcacoes) {
	        this.idEmbarcacoes = idEmbarcacoes;
	    }

	    public LocalDateTime getDataHora() {
	        return dataHora;
	    }

	    public void setDataHora(LocalDateTime dataHora) {
	        this.dataHora = dataHora;
	    }

	    public String getTipoInfracao() {
	        return tipoInfracao;
	    }

	    public void setTipoInfracao(String tipoInfracao) {
	        this.tipoInfracao = tipoInfracao;
	    }

	    public String getDescricao() {
	        return descricao;
	    }

	    public void setDescricao(String descricao) {
	        this.descricao = descricao;
	    }

	    public String getPenalidade() {
	        return penalidade;
	    }

	    public void setPenalidade(String penalidade) {
	        this.penalidade = penalidade;
	    }
	}


