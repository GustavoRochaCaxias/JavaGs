package br.com.fiap.beans;

public class PosiRastr {
	private int idpr;
	private int latidude;
	private int longitude;
	private int velocidade;
	
	public PosiRastr() {
		super();
	}

	public PosiRastr(int idpr, int latidude, int longitude, int velocidade) {
		super();
		this.idpr = idpr;
		this.latidude = latidude;
		this.longitude = longitude;
		this.velocidade = velocidade;
	}

	public int getIdpr() {
		return idpr;
	}

	public void setIdpr(int idpr) {
		this.idpr = idpr;
	}

	public int getLatidude() {
		return latidude;
	}

	public void setLatidude(int latidude) {
		this.latidude = latidude;
	}

	public int getLongitude() {
		return longitude;
	}

	public void setLongitude(int longitude) {
		this.longitude = longitude;
	}

	public int getVelocidade() {
		return velocidade;
	}

	public void setVelocidade(int velocidade) {
		this.velocidade = velocidade;
	}
	
	
	
	

}
