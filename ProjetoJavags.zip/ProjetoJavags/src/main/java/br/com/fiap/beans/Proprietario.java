package br.com.fiap.beans;

public class Proprietario {
	private int idp;
	private String nomep;
	private String infcont;
	private String email;
	private String telefone;
	
	public Proprietario() {
		super();
	}

	public Proprietario(int idp, String nomep, String infcont, String email, String telefone) {
		super();
		this.idp = idp;
		this.nomep = nomep;
		this.infcont = infcont;
		this.email = email;
		this.telefone = telefone;
	}

	public int getIdp() {
		return idp;
	}

	public void setId(int idp) {
		this.idp = idp;
	}

	public String getNomep() {
		return nomep;
	}

	public void setNomep(String nomep) {
		this.nomep = nomep;
	}

	public String getInfcont() {
		return infcont;
	}

	public void setInfcont(String infcont) {
		this.infcont = infcont;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	
}
