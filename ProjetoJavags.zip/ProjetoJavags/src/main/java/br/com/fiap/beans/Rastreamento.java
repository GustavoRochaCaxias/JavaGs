package br.com.fiap.beans;

import java.time.LocalDateTime;

public class Rastreamento {
	  private int idRastreamento;
	    private int idEmbarcacoes;
	    private int idPosicao;
	    private LocalDateTime dataHora;

	    // Getters and Setters
	    public int getIdRastreamento() {
	        return idRastreamento;
	    }

	    public void setIdRastreamento(int idRastreamento) {
	        this.idRastreamento = idRastreamento;
	    }

	    public int getIdEmbarcacoes() {
	        return idEmbarcacoes;
	    }

	    public void setIdEmbarcacoes(int idEmbarcacoes) {
	        this.idEmbarcacoes = idEmbarcacoes;
	    }

	    public int getIdPosicao() {
	        return idPosicao;
	    }

	    public void setIdPosicao(int idPosicao) {
	        this.idPosicao = idPosicao;
	    }

	    public LocalDateTime getDataHora() {
	        return dataHora;
	    }

	    public void setDataHora(LocalDateTime dataHora) {
	        this.dataHora = dataHora;
	    }

}
