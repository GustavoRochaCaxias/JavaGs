package br.com.fiap.bo;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import br.com.fiap.beans.Embarcacoes;
import br.com.fiap.dao.EmbarcacoesDao;
import br.com.fiap.conexao.ConexaoFactory;

public class EmbarcacoesBO {
		
		private EmbarcacoesDao embarcacoesDao;
		
		public EmbarcacoesBO() throws ClassNotFoundException, SQLException {
			Connection minhaConexao = new ConexaoFactory().conexao();
			this.embarcacoesDao = new EmbarcacoesDao(minhaConexao);
		}
		
		public String inserirBo(Embarcacoes embarcacoes) throws SQLException {
			return embarcacoesDao.inserir(embarcacoes);
		}
		
		public void deletarBo(int idembarcacoes ) throws ClassNotFoundException, SQLException {
			EmbarcacoesDao embarcacoesDao = new EmbarcacoesDao(null);
			embarcacoesDao.deletar(idembarcacoes);
		}	
		public ArrayList<Embarcacoes> secionarBo() throws SQLException, ClassNotFoundException{
			EmbarcacoesDao embarcacoesDao = new EmbarcacoesDao(null);
			return  (ArrayList<Embarcacoes>) embarcacoesDao.selecionar();
		}
		public void atualizarBo(Embarcacoes embarcacoes) throws ClassNotFoundException, SQLException  {
			EmbarcacoesDao embarcacoesDao = new EmbarcacoesDao(null);
			embarcacoesDao.atualizar(embarcacoes);
	}
}
