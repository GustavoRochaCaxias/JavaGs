package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Embarcacoes;
import br.com.fiap.conexao.ConexaoFactory;

public class EmbarcacoesDao {
	
	public Connection minhaConexao;

	public EmbarcacoesDao(Connection minhaConexao) throws ClassNotFoundException, SQLException {
		super();
		this.minhaConexao = new ConexaoFactory().conexao();
	}
	
	public String inserir (Embarcacoes embarcacoes) throws SQLException {
		PreparedStatement stmt = minhaConexao.prepareStatement
				(" Insert into EMBARCACOES values (?, ?, ?, ?, ?)");
			stmt.setInt(1,embarcacoes.getIdembarcacoes());
			stmt.setString(2,embarcacoes.getNomebarcacoes());
			stmt.setString(3,embarcacoes.getTipo());
			stmt.setString(4,embarcacoes.getBandeira());
			stmt.setDouble(5,embarcacoes.getPeso());
			stmt.execute();
			stmt.close();			
		return "Cadastrado com Sucesso!";
	}
	
	public String deletar(int idembarcacoes ) throws SQLException {
		PreparedStatement stmt = minhaConexao.prepareStatement
				("Delete from EMBARCACOES where IDEMBARCACOES = ?");
			stmt.setInt(1, idembarcacoes);
			stmt.execute();
			stmt.close();		
		return "Deletado com Sucesso!";
	}
	public List<Embarcacoes> selecionar() throws SQLException {
	    List<Embarcacoes> listaEmbarcacoes = new ArrayList<>();

	    String sql = "SELECT IDEMBARCACOES, NOMEBARCACOES, TIPO, BANDEIRA, PESO FROM EMBARCACOES";
	    try (PreparedStatement stmt = minhaConexao.prepareStatement(sql);
	         ResultSet rs = stmt.executeQuery()) {

	        while (rs.next()) {
	            Embarcacoes embarcacoes = new Embarcacoes();
	            embarcacoes.setIdembarcacoes(rs.getInt("IDEMBARCACOES"));
	            embarcacoes.setNomebarcacoes(rs.getString("NOMEBARCACOES"));
	            embarcacoes.setTipo(rs.getString("TIPO"));
	            embarcacoes.setBandeira(rs.getString("BANDEIRA"));
	            embarcacoes.setPeso(rs.getDouble("PESO"));
	            listaEmbarcacoes.add(embarcacoes);
	        }
	    }
	    return listaEmbarcacoes;
	}		
	
	public String atualizar(Embarcacoes embarcacoes) throws SQLException {
		PreparedStatement stmt = minhaConexao.prepareStatement
				(" Update EMBARCACOES set IDEMBARCACOES = ?,TIPO = ?, BANDEIRA=?, PESO = ? where NOMEBARCACOES = ?");
				stmt.setInt(1, embarcacoes.getIdembarcacoes());
				stmt.setString(2, embarcacoes.getTipo());
				stmt.setString(3, embarcacoes.getBandeira());
				stmt.setDouble(4, embarcacoes.getPeso());
				stmt.setString(5, embarcacoes.getNomebarcacoes());
				stmt.executeUpdate();
				stmt.close();	
		return "Atualizado com Sucesso!";
	}
	
}
