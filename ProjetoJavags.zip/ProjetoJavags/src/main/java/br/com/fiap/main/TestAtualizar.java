package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Embarcacoes;
import br.com.fiap.dao.EmbarcacoesDao;

public class TestAtualizar {
	static String texto (String j) {
		return JOptionPane.showInputDialog(j);
	}
	static int inteiro (String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}
	static double real (String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		EmbarcacoesDao dao = new EmbarcacoesDao(null);
		
		Embarcacoes objEmbarcacoes = new Embarcacoes();
		
		objEmbarcacoes.setIdembarcacoes(inteiro("Insira o Id a ser alterado"));
		objEmbarcacoes.setNomebarcacoes(texto("Nome"));
		objEmbarcacoes.setTipo(texto("Tipo"));
		objEmbarcacoes.setBandeira(texto("Bandeira"));
		objEmbarcacoes.setPeso(real("Peso"));
		
		System.out.println(dao.atualizar(objEmbarcacoes));
	}
}
