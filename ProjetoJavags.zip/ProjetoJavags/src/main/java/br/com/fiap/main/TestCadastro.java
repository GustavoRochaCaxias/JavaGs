package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Embarcacoes;
import br.com.fiap.dao.EmbarcacoesDao;


public class TestCadastro {
	static String texto (String j) {
		return JOptionPane.showInputDialog(j);
	}
	static int inteiro (String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}
	static double real (String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
			
			EmbarcacoesDao dao = new EmbarcacoesDao(null);
			
			Embarcacoes objEmbarcacoes = new Embarcacoes();
			
			objEmbarcacoes.setIdembarcacoes(inteiro("Digite o ID"));
			objEmbarcacoes.setNomebarcacoes(texto("Digite o Nome"));
			objEmbarcacoes.setTipo(texto("Digite o TIPO DE EMBARCAÇÃO"));
			objEmbarcacoes.setBandeira(texto("Digite a bandeira do navio"));
			objEmbarcacoes.setPeso(real("Digite o peso"));
			
			
			System.out.println(dao.inserir(objEmbarcacoes));

	}

}
