package br.com.fiap.main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Embarcacoes;
import br.com.fiap.dao.EmbarcacoesDao;



public class TestSelecionar {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//Instanciar objetos 
		EmbarcacoesDao dao = new EmbarcacoesDao(null);
		
		List<Embarcacoes> listaEmbarcacoes = (ArrayList<Embarcacoes>) dao.selecionar();
		
		if(listaEmbarcacoes != null) {
			// foreach 
			for( Embarcacoes embarcacoes : listaEmbarcacoes) {
				System.out.println("ID:" +embarcacoes.getIdembarcacoes() + "/NOME: " + 
									embarcacoes.getNomebarcacoes() + "/BANDEIRA: " + 
						        	embarcacoes.getBandeira() + "/Tipo: " +  
						        	embarcacoes.getTipo()+ "/PESO:" + embarcacoes.getPeso());
			}
		}

	}
}


