package br.com.fiap.main;

import java.sql.Connection;
import java.sql.SQLException;

import br.com.fiap.conexao.ConexaoFactory;

public class TesteConexao {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection cn  = new ConexaoFactory().conexao();
		
		System.out.println("Banco de Dados conectado com sucesso!!");
		
		cn.close();
	}
}
