package br.com.fiap.resource;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;
import br.com.fiap.beans.Embarcacoes;
import br.com.fiap.bo.EmbarcacoesBO;

@Path("/embarcacaoes")
public class EmbarcacoesResource {
	
	private EmbarcacoesBO embarcacoesBO;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Embarcacoes> buscar() throws SQLException, ClassNotFoundException {
		return (ArrayList<Embarcacoes>) embarcacoesBO.secionarBo();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response cadastroRs (Embarcacoes embarcacoes, @Context UriInfo uriInfo ) throws ClassNotFoundException, SQLException {
		embarcacoesBO.inserirBo(embarcacoes);
		UriBuilder builder = uriInfo.getAbsolutePathBuilder();
		builder.path(Integer.toString(embarcacoes.getIdembarcacoes()));
		return Response.created(builder.build()).build();		
	}
	@PUT
	@Path("/{idembarcacoes}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response atualizaRs (Embarcacoes embarcacoes, @PathParam("idembarcacoes") int idembarcacoes) throws SQLException, ClassNotFoundException {
		embarcacoesBO.atualizarBo(embarcacoes);
		return Response.ok().build();
	}
	@DELETE
	@Path("/{idembarcacoes}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response deleteRs (@PathParam("idembarcacoes") int idembarcacoes) throws ClassNotFoundException, SQLException {
		embarcacoesBO.deletarBo(idembarcacoes);
		return Response.ok().build();
	}

}
